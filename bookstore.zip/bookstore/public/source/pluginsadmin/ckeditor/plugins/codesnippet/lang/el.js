/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","el",{button:"Εισαγωγή Αποσπάσματος Κώδικα",codeContents:"Περιεχόμενο κώδικα",emptySnippetError:"Δεν γίνεται να είναι κενά τα αποσπάσματα κώδικα.",language:"Γλώσσα",title:"Απόσπασμα κώδικα",pathName:"απόσπασμα κώδικα"});