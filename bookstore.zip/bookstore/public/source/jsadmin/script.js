﻿  // $(document).ready(function() {
              $('div.alert').delay(3000).slideUp();
            // });